/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 * @author Inf2
 */
public class Estadistica {
    private int lineas, palabras, caracteres;
    HashMap<String, Integer> frecuenciaPalabras;

    public Estadistica () 
    {
        lineas = 0;
        palabras = 0;
        caracteres = 0;
        frecuenciaPalabras = new HashMap<String, Integer>();
    }
    
    public void analiza (String linea) 
    {
        String[] words = linea.split(" ");
        lineas++;
        palabras += words.length;
        caracteres += linea.length();
        for (String palabra : words) {
            palabra = palabra.replaceAll(":", "");
            palabra = palabra.replaceAll("\\.", "");
            palabra = palabra.replaceAll(";", "");
            palabra = palabra.replaceAll("_", "");
            palabra = palabra.replaceAll(",", "");
            if (!frecuenciaPalabras.containsKey(palabra))
                frecuenciaPalabras.put(palabra, 1);
            else {
                int oldValue = frecuenciaPalabras.get(palabra);
                frecuenciaPalabras.remove(palabra);
                frecuenciaPalabras.put(palabra, (oldValue + 1));
            }
        }
        
    }
    
    public String getResult() 
    {
        String result = "============ RESULTADOS ============\n"
                + "Nº lineas: " + getLineas() + "\n"
                + "Nº palabras: " + getPalabras() + "\n"
                + "Nº caracteres: " + getCaracteres() + "\n"
                + "   ------- PALABRAS MÁS USADAS -------\n";
        boolean isFirst = true;
        
        for (Iterator it = frecuenciaPalabras.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String, Integer> map = (Map.Entry)it.next();
            if (map.getValue() > 100)
                if (!(isFirst))
                    result += map.getKey() + "  " + map.getValue() + "\n";
                else
                    isFirst = false;
        }
        
        return result;
    }
    
    public int getLineas() {
        return lineas;
    }

    public int getPalabras() {
        return palabras;
    }

    public int getCaracteres() {
        return caracteres;
    }

    public HashMap<String, Integer> getFrecuenciaPalabras() {
        return frecuenciaPalabras;
    }

    public void setLineas(int lineas) {
        this.lineas = lineas;
    }

    public void setPalabras(int palabras) {
        this.palabras = palabras;
    }

    public void setCaracteres(int caracteres) {
        this.caracteres = caracteres;
    }

    public void setFrecuenciaPalabras(HashMap<String, Integer> frecuenciaPalabras) {
        this.frecuenciaPalabras = frecuenciaPalabras;
    }
    
    
    
}
